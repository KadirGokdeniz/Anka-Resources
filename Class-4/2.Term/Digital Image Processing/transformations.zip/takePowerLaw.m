I=imread("gray_level.jpg");

% Convert the image to double datatype for calculations
convertedI=im2double(I);

% Constant to determine the nature of the log curve
%to obtain a brighter image increase it
c=1.0;

%for gamma=0.04 --> lightened image obtained
%for gamma=25.0 --> darkened image obtained
gamma=0.5;

logI=c*convertedI.^gamma;



subplot(1,2,1), imshow(I),title('ORIGINAL GRAY-SCALE  8-BIT IMAGE')
subplot(1,2,2), imshow(logI),title('POWER LAW TRANSFORMED IMAGE')