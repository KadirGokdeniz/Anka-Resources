I=imread("gray_level.jpg");

% Convert the image to double datatype for calculations
convertedI=im2double(I);

% Constant to determine the nature of the log curve
%to obtain a brighter image increase it default=1.0
c=1.0;

logI=c*log(1+convertedI);



subplot(1,2,1), imshow(I),title('ORIGINAL GRAY-SCALE  8-BIT IMAGE')
subplot(1,2,2), imshow(logI),title('LOG-TRANSFORMED IMAGE')