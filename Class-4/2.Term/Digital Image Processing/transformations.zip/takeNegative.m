I=imread("gray_level.jpg");

neg=255-I;

imshow(neg);

subplot(1,2,1), imshow(I),title('ORIGINAL GRAY-SCALE  8-BIT IMAGE')
subplot(1,2,2), imshow(neg),title('NEGATIVE IMAGE')