%obtain a B&W (binary) image
grayImage=imread("gray_level.jpg");


[rows,cols]=size(grayImage);
newBinaryImage=zeros(rows,cols);



for i=1:rows
    for j=1:cols
        if grayImage(i,j)<=127 %threshold value
            newBinaryImage(i,j)=0;
        else
            newBinaryImage(i,j)=255;
        end
    end
end

%show images
subplot(1,2,1), imshow(grayImage),title('GRAYSCALE IMAGE')
subplot(1,2,2), imshow(newBinaryImage),title('BINARY IMAGE')