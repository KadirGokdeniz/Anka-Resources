grayImage=imread("gray_level.jpg");
ourFilter=[-1 -1 -1;...
            0 0 0; ...
            1 1 1];

filteredImage=imfilter(grayImage,ourFilter);

%show the original and filtered images side by side

% subplot(1,2,1), imshow(grayImage),title('ORIGINAL GRAY-SCALE  8-BIT IMAGE')
% subplot(1,2,2), imshow(filteredImage),title('FILTERED IMAGE')


%display side by side
imshowpair(grayImage,filteredImage,'montage')