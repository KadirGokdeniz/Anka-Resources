%open the image
ourImage=imread('truecolor_image.png');

subplot(1,3,1), imshow(ourImage(:,:,1))
subplot(1,3,2), imshow(ourImage(:,:,2))
subplot(1,3,3), imshow(ourImage(:,:,3))