grayImage=imread("gray_level.jpg");

[rows,cols,chs]=size(grayImage);

imshow(grayImage);