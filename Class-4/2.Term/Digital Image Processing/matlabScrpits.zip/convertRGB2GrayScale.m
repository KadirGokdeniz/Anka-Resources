rgbImage=imread("truecolor_image.png");

%convert to double before processing the original IMAGE!
rgbImage=double(rgbImage);
[rows,cols,chs]=size(rgbImage);
newGrayScaleImage=(zeros(rows,cols));
newGrayScaleImage=double(newGrayScaleImage);

for i=1:rows
    for j=1:cols
        redChannelPixelValue=rgbImage(i,j,1);
        greenChannelPixelValue=rgbImage(i,j,2);
        blueChannelPixelValue=rgbImage(i,j,3);
        newGrayScaleImage(i,j)=(redChannelPixelValue+greenChannelPixelValue+...
            blueChannelPixelValue)/3;
    end
end

newGrayScaleImage=uint8(newGrayScaleImage);

%show images
subplot(1,2,1), imshow(uint8(rgbImage)),title('RGB IMAGE')
subplot(1,2,2), imshow((newGrayScaleImage)),title('GRAY-SCALE IMAGE')