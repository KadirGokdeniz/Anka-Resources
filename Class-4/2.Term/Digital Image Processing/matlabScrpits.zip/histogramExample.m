grayImage=imread("edgeImage.jpg");
[rows,cols]=size(grayImage);


histogramArray=uint16(zeros(1,256));

for i=1:rows
    for j=1:cols
        value=grayImage(i,j);
        if value==0 %!!!we do not have a 0 index in histogramArray!!!
            histogramArray(1,256)=histogramArray(1,256)+1;
        else
            histogramArray(1,value)=histogramArray(1,value)+1;
    
        end
    end
end

%for control
%sum(grayImage(:) == 3)

plot(histogramArray)
%histogram(grayImage,255)