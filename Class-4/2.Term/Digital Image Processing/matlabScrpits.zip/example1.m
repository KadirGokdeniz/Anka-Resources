%opening an image file

ourImage=imread('truecolor_image.png');

%showing an image
imshow(ourImage);

%obtaining the size of an image
[rows,cols,channels]=size(ourImage);

%showing the red channel
imshow(ourImage(:,:,1))

%showing the green channel
imshow(ourImage(:,:,2))

%showing the blue channel
imshow(ourImage(:,:,3))