%open the image
ourImage=imread('truecolor_image.png');


imshow(ourImage(:,:,1))
figure
imshow(ourImage(:,:,2))
figure
imshow(ourImage(:,:,3))