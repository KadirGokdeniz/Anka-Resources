%open the image
ourImage=imread('truecolor_image.png');

% 2 rows, 3 cols
subplot(2,3,1), imshow(ourImage(:,:,1)),title('RED CHANNEL')
subplot(2,3,2), imshow(ourImage(:,:,2)),title('GREEN CHANNEL')
subplot(2,3,3), imshow(ourImage(:,:,3)),title('BLUE CHANNEL')
subplot(2,3,4), imshow(ourImage),title('RGB CHANNELS')


%cyan(0,255,255)
%magenta (255,0,255)