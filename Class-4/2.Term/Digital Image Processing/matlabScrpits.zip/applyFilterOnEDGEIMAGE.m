grayImage=imread("edgeImage.jpg");
ourFilter=[-1 -1 -1;... % vertical transitions for horizontal edges
            0 0 0; ...
            1 1 1];

filteredImage=imfilter(grayImage,ourFilter);

%display side by side
imshowpair(grayImage,filteredImage,'montage')

ourFilter2=[-1  0 1;... % horizontal transitions for veritcal edges
            -1 0 1; ...
            -1 0 1];

filteredImage2=imfilter(grayImage,ourFilter2);
imshowpair(grayImage,filteredImage2,'montage')

%show images
subplot(1,3,1), imshow(grayImage),title('GRAYSCALE IMAGE')
subplot(1,3,2), imshow(filteredImage),title('FILTERED 1')
subplot(1,3,3), imshow(filteredImage2),title('FILTERED 2')